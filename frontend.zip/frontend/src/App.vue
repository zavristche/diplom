<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import Header from './components/Header.vue';
import Footer from './components/Footer.vue';

const router = useRouter();
const isReady = ref(false);

onMounted(async () => {
  // Пропускаем загрузку для not-found
  if (router.currentRoute.value.name === 'not-found') {
    isReady.value = true;
    return;
  }

  try {
    isReady.value = true; // Устанавливаем true сразу, если загрузка не требуется
  } catch (error) {
    console.error('App.vue: Error during initialization:', error);
    isReady.value = true;
  }
});
</script>

<template>
  <div class="app-container">
    <div v-if="!isReady" class="loading-overlay">
      <div class="spinner"></div> <!-- Анимированный спиннер -->
    </div>

    <router-view v-else v-slot="{ Component }">
      <transition name="fade-slide" mode="out-in">
        <div>
          <Header />
          <main>
            <transition name="fade" appear>
              <component :is="Component" />
            </transition>
          </main>
          <Footer />
        </div>
      </transition>
    </router-view>
  </div>
</template>

<style scoped lang="scss">
@use "./assets/styles/_variables" as *;

.app-container {
  width: 100vw;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  overflow-x: hidden;
}

.loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
  
  .spinner {
    width: 50px;
    height: 50px;
    border: 4px solid rgba(255, 255, 255, 0.3);
    border-radius: 50%;
    border-top-color: #fff;
    animation: spin 1s ease-in-out infinite;
  }
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

main {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 50px;
  justify-content: center;
  width: 1200px;
  max-width: 1200px;
  margin: 50px auto 0;
}

/* Плавное появление + сдвиг */
.fade-slide-enter-active,
.fade-slide-leave-active {
  transition: all 0.4s ease;
}
.fade-slide-enter-from {
  opacity: 0;
  transform: translateY(10px);
}
.fade-slide-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}

/* Плавное появление контента */
.fade-enter-active {
  transition: opacity 0.5s ease 0.2s;
}
.fade-enter-from {
  opacity: 0;
}
</style>