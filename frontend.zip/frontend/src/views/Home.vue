<script setup>
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";
import RecipeService from "../api/RecipeService";
import { useRecipeStore } from "../stores/recipe";
import BaseIcon from "../components/BaseIcon.vue";
import Recipe from "../components/Recipe.vue";
import Search from "../components/Search.vue";

const router = useRouter();
const recipeStore = useRecipeStore();
const recipes = ref(recipeStore.recipes);
const isLoading = ref(!recipes.value.length);

onMounted(async () => {
  if (!recipes.value.length) {
    await recipeStore.fetchRecipes();
    recipes.value = recipeStore.recipes;
  }
  isLoading.value = false;
});

const getRandomRecipe = async () => {
  try {
    console.log("Starting getRandomRecipe...");
    console.log("Calling RecipeService.getRandom()...");
    const response = await RecipeService.getRandom();
    console.log("Random API response:", response.data);
    const recipeId = response.data.id;
    if (recipeId) {
      console.log("Navigating to /recipe/", recipeId);
      router.push(`/recipe/${recipeId}`);
    } else {
      console.log("No valid recipeId, redirecting to /not-found");
      router.push('/not-found');
    }
  } catch (error) {
    console.error("Error in getRandomRecipe:", error);
    console.error("Error details:", error.response?.data || error.message);
    router.push('/not-found');
  }
};
</script>

<template>
  <section class="hero">
    <div class="container-col">
      <h1>РЕЦЕПТИЩЕ</h1>
      <p class="slogan">Готовь просто – удивляй вкусно!</p>
      <Search />
      <button type="button" class="btn-dark line" @click="getRandomRecipe">
        <BaseIcon viewBox="0 0 45 45" class="icon-dark-45-1" name="random" />Случайный рецепт
      </button>
    </div>
    <img src="/img/mascot.png" alt="Mascot" width="600" height="760" />
  </section>
  <section class="content-container">
    <div v-if="isLoading" v-for="n in 6" :key="n" class="skeleton-card"></div>
    <Recipe v-else v-for="recipe in recipes" :key="recipe.id" :recipe="recipe" />
  </section>
</template>

<style lang="scss">
@use "../assets/styles/variables" as *;

.content-container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 40px;
}

.skeleton-container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 40px;
}

.skeleton-card {
  height: 280px;
  background: #eee;
  border-radius: 8px;
  animation: pulse 1.5s infinite;
}

@keyframes pulse {
  0% { opacity: 1; }
  50% { opacity: 0.5; }
  100% { opacity: 1; }
}

.hero {
  display: flex;
  align-items: center;

  h1 {  
    font-weight: 600;
    font-size: 100px;
  }

  .search {
    box-shadow: $shadow;
  }

  .container-col {
    height: 19rem;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }

  img {
    width: 524px;
    height: 580px;
    object-fit: cover;
  }
}

.slogan {
  font-size: 32px;
}
</style>