import { createRouter, createWebHistory } from 'vue-router';
import { useRecipeStore } from './stores/recipe';
import { useProfileStore } from './stores/profile';
import { useCollectionStore } from './stores/collection';
import { useAuthStore } from './stores/auth';

import Home from './views/Home.vue';
import Search from './views/Search.vue';
import RecipeCreate from './views/recipe/Create.vue';
import RecipeEdit from './views/recipe/Edit.vue';
import CollectionCreate from './views/collection/Create.vue';
import CollectionView from './views/collection/View.vue';
import CollectionEdit from './views/collection/Edit.vue';
import AdminHome from './views/admin/Home.vue';
import NotFound from './views/NotFound.vue';

const routes = [
  { path: '/', name: 'home', component: Home, meta: { title: 'Рецептище' } },
  { path: '/search/:type(recipe|collection|user)?', name: 'search', component: Search, meta: { title: 'Поиск' } },
  { path: '/recipe/:id', name: 'RecipeView', component: () => import('./views/recipe/View.vue'), meta: { title: 'Рецепт' } },
  { path: '/profile/:id', name: 'ProfileView', component: () => import('./views/profile/View.vue'), meta: { title: 'Профиль' } },
  {
    path: '/recipe/create',
    name: 'recipe-create',
    component: RecipeCreate,
    meta: { title: 'Создать рецепт', store: useRecipeStore, fetch: 'fetchCreateData', dataField: 'createData', redirect: NotFound },
    async beforeEnter(to, from, next) {
      const store = useRecipeStore();
      try {
        if (!store[to.meta.dataField]) await store[to.meta.fetch]();
        to.meta.data = store[to.meta.dataField];
        next(to.meta.data ? undefined : { name: 'not-found', replace: true });
      } catch {
        next({ name: 'not-found', replace: true });
      }
    },
  },
  {
    path: '/recipe/edit/:id',
    name: 'recipe-edit',
    component: RecipeEdit,
    meta: { title: 'Редактировать рецепт', store: useRecipeStore, fetch: 'fetchCreateData', dataField: 'createData', fetchItem: 'fetchRecipeById', itemField: 'recipe', redirect: NotFound },
    async beforeEnter(to, from, next) {
      const store = useRecipeStore();
      try {
        if (!store[to.meta.dataField]) await store[to.meta.fetch]();
        to.meta.data = store[to.meta.dataField];
        to.meta[to.meta.itemField] = await store[to.meta.fetchItem](to.params.id);
        next(to.meta.data && to.meta[to.meta.itemField] ? undefined : { name: 'not-found', replace: true });
      } catch {
        next({ name: 'not-found', replace: true });
      }
    },
  },
  {
    path: '/collection/create',
    name: 'collection-create',
    component: CollectionCreate,
    meta: { title: 'Создать коллекцию', store: useCollectionStore, fetch: 'fetchCreateData', dataField: 'createData', redirect: NotFound },
    async beforeEnter(to, from, next) {
      const store = useCollectionStore();
      try {
        if (!store[to.meta.dataField]) await store[to.meta.fetch]();
        to.meta.data = store[to.meta.dataField];
        next(to.meta.data ? undefined : { name: 'not-found', replace: true });
      } catch {
        next({ name: 'not-found', replace: true });
      }
    },
  },
  { path: '/collection/:id', name: 'collection', component: CollectionView, meta: { title: 'Коллекция' } },
  {
    path: '/collection/edit/:id',
    name: 'collection-edit',
    component: CollectionEdit,
    meta: { title: 'Редактировать коллекцию', store: useCollectionStore, fetch: 'fetchCreateData', dataField: 'createData', fetchItem: 'fetchCollectionById', itemField: 'collection', redirect: NotFound },
    async beforeEnter(to, from, next) {
      const store = useCollectionStore();
      try {
        if (!store[to.meta.dataField]) await store[to.meta.fetch]();
        to.meta.data = store[to.meta.dataField];
        to.meta[to.meta.itemField] = await store[to.meta.fetchItem](to.params.id);
        next(to.meta.data && to.meta[to.meta.itemField] ? undefined : { name: 'not-found', replace: true });
      } catch {
        next({ name: 'not-found', replace: true });
      }
    },
  },
  {
    path: '/admin',
    name: 'admin',
    component: AdminHome,
    meta: { title: 'Админ-панель' },
    beforeEnter(to, from, next) {
      const authStore = useAuthStore();
      if (!authStore.isAuthenticated || !authStore.isAdmin) {
        return next({ name: 'not-found', replace: true });
      }
      next();
    },
  },
  { path: '/:pathMatch(.*)*', name: 'not-found', component: NotFound, meta: { title: 'Страница не найдена' } },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

// Универсальный хук для установки заголовка
router.beforeEach(async (to, from, next) => {
  const stores = {
    RecipeView: { store: useRecipeStore(), fetch: 'fetchRecipeById', field: 'title', defaultTitle: 'Рецепт' },
    ProfileView: { store: useProfileStore(), fetch: 'fetchProfileById', field: 'login', defaultTitle: 'Профиль' },
    collection: { store: useCollectionStore(), fetch: 'fetchCollectionById', field: 'title', defaultTitle: 'Коллекция' },
  };

  let title = to.meta.title || 'Рецептище';
  const routeConfig = stores[to.name];
  if (routeConfig && to.params.id) {
    try {
      const item = await routeConfig.store[routeConfig.fetch](to.params.id);
      if (!item) return next({ name: 'not-found', replace: true });
      title = item[routeConfig.field] || routeConfig.defaultTitle;
    } catch {
      title = `${routeConfig.defaultTitle} не найден`;
      return next({ name: 'not-found', replace: true });
    }
  }

  document.title = title;
  window.scrollTo({ top: 0, behavior: 'smooth' });
  next();
});

export default router;