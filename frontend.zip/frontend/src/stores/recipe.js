import { defineStore } from 'pinia';
import RecipeService from '../api/RecipeService';

export const useRecipeStore = defineStore('recipe', {
  state: () => ({
    recipes: [],
    currentRecipe: null,
    createData: null,
  }),
  actions: {
    async fetchRecipes() {
      try {
        const response = await RecipeService.getAll();
        this.recipes = Array.isArray(response.data) ? response.data : [];
      } catch (error) {
        throw error;
      }
    },
    async fetchRecipeById(id) {
      if (this.currentRecipe?.id === id) {
        return this.currentRecipe;
      }
      try {
        const response = await RecipeService.getById(id);
        this.currentRecipe = response.data;
        return response.data;
      } catch (error) {
        this.currentRecipe = null;
        throw error;
      }
    },
    async fetchCreateData() {
      if (this.createData) return;
      try {
        const response = await RecipeService.getCreateData();
        this.createData = response.data;
      } catch (error) {
        throw error;
      }
    },
    async searchRecipes(query) {
      try {
        const response = await RecipeService.search(query);
        this.recipes = Array.isArray(response.data.recipes) ? response.data.recipes : [];
      } catch (error) {
        this.recipes = [];
        throw error;
      }
    },
    clearRecipes() {
      this.recipes = [];
    },
    async fetchRandomRecipe() {
      try {
        const response = await RecipeService.random(); // Используем метод random
        this.currentRecipe = response.data.recipe;
        return this.currentRecipe;
      } catch (error) {
        this.currentRecipe = null;
        throw error;
      }
    },
  },
});